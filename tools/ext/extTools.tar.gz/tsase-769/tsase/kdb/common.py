import glob
import os
import numpy
import sys
import re
import subprocess
try:
    from .aselite import elements
    from .aselite import elements_groups
except ImportError:
    from .aselite import elements


def string_split(system):
 return re.findall('[A-Z][a-z]*', str(system))
#print string_split("LiFeO")
#print elements['Li']['prime_number']

def name_to_code(name):
 name_array = string_split(name)
 code =1
 for element in name_array:
  code *= elements[element]['prime_number']
 return code

#print name_to_code("LiHO")

class Kdb():
    def check_svn_version(self):
        #does not work
        svn_info = subprocess.check_output("svn info")
        print(svn_info)

    def check_version(self):
#        print(sys.version)
#        if sys.version_info[:2] != (3.5):
#            print("python 3.5.X required.")
#            return False
        return True


    def atomAtomPbcVector(self, atoms, a, b):
        if not hasattr(atoms, 'ibox'):
            atoms.ibox = numpy.linalg.inv(atoms.get_cell())
        if not hasattr(atoms, 'pbcVectors'):
            atoms.pbcVectors = {}
        if (a, b) not in atoms.pbcVectors or (b, a) not in atoms.pbcVectors:
            atoms.pbcVectors[(a, b)] = self.pbc(atoms.positions[b] - atoms.positions[a], atoms.get_cell(), atoms.ibox)
            atoms.pbcVectors[(b, a)] = -atoms.pbcVectors[(a, b)]
        return atoms.pbcVectors[(a, b)]


    def atomAtomPbcDistance(self, atoms, a, b):
        if not hasattr(atoms, 'pbcDistances'):
            atoms.pbcDistances = {}
        if (a, b) not in atoms.pbcDistances or (b, a) not in atoms.pbcDistances:
            atoms.pbcDistances[(a, b)] = numpy.linalg.norm(self.atomAtomPbcVector(atoms, a, b))
            atoms.pbcDistances[(b, a)] = atoms.pbcDistances[(a, b)]
        return atoms.pbcDistances[(a, b)]


    def atomAtomDistance(self, atoms, a, b):
        if not hasattr(atoms, 'distances'):
            atoms.distances = {}
        if (a, b) not in atoms.distances or (b, a) not in atoms.distances:
            atoms.distances[(a, b)] = numpy.linalg.norm(atoms.positions[a] - atoms.positions[b])
            atoms.distances[(b, a)] = atoms.distances[(a, b)]
        return atoms.distances[(a, b)]


    def getNameList(self, atoms):
        """
        Returns a sorted list of element names.
        """
        nl = []
        for name in atoms.get_chemical_symbols():
            if name not in nl:
                nl.append(name)
        return sorted(nl)


    def nameCount(self, atoms):
        counts = {}
        for name in atoms.get_chemical_symbols():
            if not name in counts:
                counts[name] = 0
            counts[name] += 1
        return counts


    def pbc(self, r, box, ibox = None):
        """
        Applies periodic boundary conditions.
        Parameters:
            r:      the vector the boundary conditions are applied to
            box:    the box that defines the boundary conditions
            ibox:   the inverse of the box. This will be calculuated if not provided.
        """
        #if ibox == None:
        #if not hasattr(ibox, 'shape'):
        if type(ibox) != numpy.ndarray and type(ibox) != list and type(ibox) != tuple: #MJW fix
            ibox = numpy.linalg.inv(box)
        vdir = numpy.dot(r, ibox)
        vdir = (vdir % 1.0 + 1.5) % 1.0 - 0.5
        return numpy.dot(vdir, box)


    def per_atom_norm(self, v, box, ibox = None):
        '''
        Returns a length N numpy array containing per atom distance
            v:      an Nx3 numpy array
            box:    box matrix that defines the boundary conditions
            ibox:   the inverse of the box. will be calculated if not provided
        '''
        diff = self.pbc(v, box, ibox)
        return numpy.array([numpy.linalg.norm(d) for d in diff])


    def load_mode(self, modefilein):
        ''' 
        Reads a mode.dat file into an N by 3 numpy array
            modefilein: filename
        '''
        f = open(modefilein, 'r')
        lines = f.readlines()
        f.close()
        mode = []
        for line in lines:
            l = line.strip().split()
            for j in range(3):
                mode.append(float(l[j]))
        mode = numpy.array(mode)
        mode.resize(len(mode)/3, 3)
        return mode


    def save_mode(self, modefileout, displace_vector):
        '''
        Saves an Nx3 numpy array into a mode.dat file. 
            modefileout:     filename
            displace_vector: the mode (Nx3 numpy array)
        '''
        f = open(modefileout, 'w')
        for i in range(len(displace_vector)):
            f.write("%.3f %.3f %.3f\n" % (displace_vector[i][0],
                displace_vector[i][1], displace_vector[i][2]))

    def list_element_combinations(self, kdbdir):
        combinations = [os.path.basename(i) for i in glob.glob(os.path.join(kdbdir, "*"))]
        return combinations

    def combo_split(self, combo):
        elements = []
        for i in range(len(combo)):
            if combo[i] == combo[i].lower():
                elements[-1] += combo[i]
            else:
                elements.append(combo[i])
        return elements

    def is_symbol_subset(self, a, b):
        for symbol in a:
            if symbol not in b:
                return False
        return True

    def query_has_all(self, kdbdir, symbols):
        result = []
        combinations = [os.path.basename(i) for i in glob.glob(os.path.join(kdbdir, "*"))]
        for combo in combinations:
            elements = self.combo_split(combo)
            if not is_symbol_subset(symbols, elements):
                continue
            for N in glob.glob(os.path.join(kdbdir, combo, '*')):
                result.append(N)
        return result

    def check_kdb_combinations(self,name,kdbinputlist):
        match_list = []
        for k in range(0, len(kdbinputlist)):
                kdbinput_in_use = str(kdbinputlist[k])
                inputlist = re.findall('[A-Z][a-z]*', str(name))
                print(kdbinput_in_use)
                count = 0
                for i in range(0,len(inputlist)):
                        kdbseperationlist = re.findall('[A-Z][a-z]*', str(kdbinput_in_use))
                        inputlist = re.findall('[A-Z][a-z]*', str(name))
                        inputelement = inputlist[i]
                        #print inputelement
                        #print kdbseperationlist
                        #print inputlist
                        for j in range(0,len(kdbseperationlist)):
                                #print inputelement
                                #print kdbseperationlist[j]
                                if inputelement == kdbseperationlist[j]:
                                        count = count + 1;
                                        print(count)
                if count == len(kdbseperationlist):
                        match_list.append(kdbinput_in_use)
        return match_list

    def string_split(self,system):
        return re.findall('[A-Z][a-z]*', str(system))
        #print string_split("LiFeO")
        #print elements['Li']['prime_number']

    def name_to_code(self,name):
        name_array = string_split(name)
        code =1
        for element in name_array:
            code *= elements[element]['prime_number']
        return code
        #print name_to_code("LiHO")

    def name_to_type_code(self,name):
        name_array = string_split(name)
        unique_type_list = []
        code = 1
        for element in name_array:#for each element in process
         type_element = elements[element]['elemental_type'] #i.e AM,AEM,NG etc
         if type_element in unique_type_list:
          continue
         else:
          unique_type_list.append(type_element)
        for type_element in unique_type_list:
         code *= elements_groups[type_element]['prime_number']#multiply the prime num of that type
         similar_atom_code = code
        return similar_atom_code

    def name_to_type(self,name):
     type = elements[name]['elemental_type']
     return type

    def similar_atom_nameCount(self, atoms):
        counts = {}
        for name in atoms.get_chemical_symbols():
            group_name = self.name_to_type(name)
            if not group_name in counts:
             counts[group_name] = 0
            counts[group_name] += 1
        return counts
