# This file holds variables that will never be changed during execution.

# The below parameters are only used when a database has not been created.
MOBILE_ATOM_CUTOFF = 0.7
NEIGHBOR_FUDGE = 0.2
DISTANCE_CUTOFF = 0.3
PBC_MAPPING_CHECK = True
REBOX_SUGGESTIONS = False
KEEP_BARRIERS = False
ENERGY_CEILING = 0.0
ENERGY_FLOOR = 0.0
USE_GROUP_SIMILARITY = False
KDB_NAME = 'kdb.db'
