#List of variables used through remote package

db_name = 'kdb'
backup_db_name = 'kdb_backup'
user_db_name = 'kdb_user'

#note these variables should only be set on the server
#client's do not need these.
user = 'root'
password = 'lepsho'
port = 3306
host = 'localhost'
