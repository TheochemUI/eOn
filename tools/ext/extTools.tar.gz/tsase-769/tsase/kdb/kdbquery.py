#!/usr/bin/env python

import os
import sys
import numpy 
import glob
import shutil
import math
import copy

from optparse import OptionParser

from .common import Kdb
from .config import *
from .aselite import elements
from .aselite import elements_groups
from .aselite import write_vasp

class KdbQuery(Kdb):
    def __init__(self):
        self.return_dict = {}

    def isDistance(self, pbcvector, target, box, dc):
        for x in [-1, 0, 1]:
            for y in [-1, 0, 1]:
                for z in [-1, 0, 1]:
                    temp = pbcvector.copy()
                    temp += x * box[0]
                    temp += y * box[1]
                    temp += z * box[2]
                    if abs(numpy.linalg.norm(temp) - target) < dc:
                        return True
        return False


    def isDistance2(self, pbcvector, target, box, dc):
        ref = pbcvector.copy()
        for x in [-1, 0, 1]:
            ref1 = ref + x * box[0]
            for y in [-1, 0, 1]:
                ref2 = ref1 + y * box[1]
                for z in [-1, 0, 1]:
                    ref3 = ref2 + z * box[2]
                    if abs(numpy.linalg.norm(ref3) - target) < dc:
                        return True
        return False


    def isDistance3(self, pbcvector, target, box, dc):
        ref = pbcvector.copy()
        
        xRange = [-1, 0, 1]
        if numpy.linalg.norm(box[0])/2.0 > target:
           xRange = [0]
        yRange = [-1, 0, 1]
        if numpy.linalg.norm(box[1])/2.0 > target:
           xRange = [0]
        zRange = [-1, 0, 1]
        if numpy.linalg.norm(box[2])/2.0 > target:
           xRange = [0]

        for x in xRange:
            ref1 = ref + x * box[0]
            for y in yRange:
                ref2 = ref1 + y * box[1]
                for z in zRange:
                    ref3 = ref2 + z * box[2]
                    if abs(numpy.linalg.norm(ref3) - target) < dc:
                        return True
        return False


    def centroid(self, a, which=None):
        if which == None:
            which = list(range(len(a)))
        c = numpy.array([0.0, 0.0, 0.0])
        for i in which:
            c += a.positions[i]
        c /= len(which)
        return c


    def clump(self, c, atoms, nf):
        # Remove PBC's.
        temp = c.copy()
        undone = atoms[:]
        working = [undone.pop(0)] # using the first atom to do remove pbc which makes sense as it is the mobile atoms
        while len(undone) > 0:
            if len(working) == 0:
                print("Dissociated reactant, or neighbor_fudge too small.")
                return 
            a = working.pop()
            for i in undone[:]:
                v = self.pbc(temp.positions[i] - temp.positions[a], temp.cell)
#                d = numpy.linalg.norm(v)
#                if d < (elements[temp.get_chemical_symbols()[a]]["radius"] + elements[temp.get_chemical_symbols()[i]]["radius"]) * (1.0 + nf):
                temp.positions[i] = temp.positions[a] + v
                working.append(i)
                undone.remove(i)
        return temp

    def query_db(self, **args):
        print("function not yet overloaded")

    #note this function gets overloaded when interacting with remote DB
    def output_query(self, outputdir, numMatches, suggestion, sugproduct, modeTemp=None,processBarrier=None):
        #create direcotry if none exists.
        if not os.path.isdir(outputdir):
            os.mkdir(outputdir)
        #write the files to the output
        write_vasp(outputdir + "/SADDLE_%d" % numMatches, suggestion)
        write_vasp(outputdir + "/PRODUCT_%d" % numMatches, sugproduct)
        if modeTemp is not None:
            self.save_mode(outputdir + "/MODE_%d" % numMatches, modeTemp)
        if processBarrier is not None:
            if (processBarrier[0] !=0 or processBarrier[1] !=0):
                complete_name = os.path.join(outputdir+"/Barrier_%d" % numMatches+".txt")
                #print ("complete_name: ",complete_name)
                with open(complete_name,'w') as f:
                    f.write(str(processBarrier))
                f.close()
        os.system("touch %s/.done_%d" % (outputdir, numMatches))

    def query(self, reactant, outputdir = "./kdbmatches", nf=0.2, dc=0.3, nodupes = False, kdbname = 'kdb.db'):
        # XXX: I think the best way forward to allow parallel processes
        # here is to make the query function return atoms objects instead
        # of writing them to file there.

        # Get the ibox to speed up pbcs.
        ibox = numpy.linalg.inv(reactant.cell)

        # Remove directory if kdbmatches is already there.
        if os.path.isdir(outputdir):
            shutil.rmtree(outputdir)
        # A list of unique saddles, used for duplicate removal.
        uniques = []

        # Get a list of kdb entries that match the query configuration elementally.
        entries, name = self.query_db(kdbname = kdbname, reactant = reactant)

        print("name: ",name)

        if len(entries) == 0:
            print("No entries for those elements.")
            return

        # For each nonfrozen atom in reactant, create a list of neighboring element
        # types and the count of each type.
        # TODO: this can be made N^2/2 trivially.
        # TODO: this can use SAP for ortho boxes.
        reactantNeighbors = {}
        for i in range(len(reactant)):
            if i in reactant.constraints[0].index:
                continue
            if USE_GROUP_SIMILARITY:
                group_free_atom = Kdb().name_to_type(reactant.get_chemical_symbols()[i])
                r1 = elements_groups[group_free_atom]["radius"]
            else:
                r1 = elements[reactant.get_chemical_symbols()[i]]["radius"]
            reactantNeighbors[i] = {}
            for j in range(len(reactant)):
                if j == i:
                    continue
                if USE_GROUP_SIMILARITY:
                    group_neighbor_atom = Kdb().name_to_type(reactant.get_chemical_symbols()[j])
                    r2 = elements_groups[group_neighbor_atom]["radius"]
                else:
                    r2 = elements[reactant.get_chemical_symbols()[j]]["radius"]
                d = numpy.linalg.norm(self.pbc(reactant.positions[i] - reactant.positions[j], reactant.cell, ibox))
                if d > (r1 + r2) * (1 + nf):
                    continue
                if USE_GROUP_SIMILARITY:
                    if group_neighbor_atom not in reactantNeighbors[i]:
                        reactantNeighbors[i][group_neighbor_atom] =0
                    reactantNeighbors[i][group_neighbor_atom] +=1
                else:
                    if reactant.get_chemical_symbols()[j] not in reactantNeighbors[i]:
                        reactantNeighbors[i][reactant.get_chemical_symbols()[j]] = 0
                    reactantNeighbors[i][reactant.get_chemical_symbols()[j]] += 1

        # Create a list of element types and counts for the entire reactant.
        if USE_GROUP_SIMILARITY:
            reactantNameCount = self.similar_atom_nameCount(reactant)
        else:
            reactantNameCount = self.nameCount(reactant)
        print ("reactantNameCount: ",reactantNameCount)
        #print ("type_reactantNameCount: ",type_reactantNameCount)
        numMatches = 0
        ###########################################################################
        # (Main) Loop over each kdb entry.
        ###########################################################################
        for entry in entries:

            entryMatches = 0

            mirrored = "not mirrored"
            if entry["mirror"]:
                mirrored = "mirrored"
            # print "checking", name, "with id:", entry['id'], mirrored
            print("KDB checking entry:", entry['id'], "(",mirrored,")")

            # Load the minimum.
            kdbmin = copy.deepcopy(entry['minimum'])

            # Make sure the reactant has at least as many atoms of each type as the
            # kdb configuration.
            passedNameCount = True
            if not USE_GROUP_SIMILARITY:
             kdbNameCount = self.nameCount(kdbmin)
            else:
             kdbNameCount = self.similar_atom_nameCount(kdbmin)
            print ("kdbNameCount: ",kdbNameCount)
            for name in kdbNameCount:
                if name not in reactantNameCount:
                    passedNameCount = False
                    break
                if kdbNameCount[name] > reactantNameCount[name]:
                    passedNameCount = False
                    break
            if not passedNameCount:
                print("%10d  name count fail" % entryMatches)
                continue
            else:
                print ("Passed Name Count")
            # Load the mobile atoms list.
            kdbmobile = copy.deepcopy(entry['mobile'])

            # Mirror the minimum if the mirror flag is set for this entry.
            if entry["mirror"]:
                for i in range(len(kdbmin)):
                    kdbmin.positions[i] += 2.0 * (kdbmin.positions[0] - kdbmin.positions[i])

            # For each mobile atom in kdbmin, create a list of neighboring element
            # types and the count of each type.
            kdbNeighbors = {}
            for i in kdbmobile:
                if USE_GROUP_SIMILARITY:
                    group_free_atom = Kdb().name_to_type(kdbmin.get_chemical_symbols()[i])
                    print ("group_free_atom: ",group_free_atom)
                    r1 = elements_groups[group_free_atom]["radius"]
                else:
                    r1 = elements[kdbmin.get_chemical_symbols()[i]]["radius"]
                kdbNeighbors[i] = {}
                for j in range(len(kdbmin)):
                    if j == i:
                        continue
                    if USE_GROUP_SIMILARITY:
                        group_neighbor_atom = Kdb().name_to_type(kdbmin.get_chemical_symbols()[j])#get group of neighbor atom , i.e 'TM'
                        r2 = elements_groups[group_neighbor_atom]["radius"]
                    else:
                        r2 = elements[kdbmin.get_chemical_symbols()[j]]["radius"]
                    d = numpy.linalg.norm(kdbmin.positions[i] - kdbmin.positions[j])
                    if d > (r1 + r2) * (1 + nf):
                        continue
                    if USE_GROUP_SIMILARITY:
                     if group_neighbor_atom not in kdbNeighbors[i]:
                        kdbNeighbors[i][group_neighbor_atom] = 0
                     kdbNeighbors[i][group_neighbor_atom] += 1
                    else:
                     if kdbmin.get_chemical_symbols()[j] not in kdbNeighbors[i]:
                        kdbNeighbors[i][kdbmin.get_chemical_symbols()[j]] = 0
                     kdbNeighbors[i][kdbmin.get_chemical_symbols()[j]] += 1

            kdbUnmapped = list(range(len(kdbmin))) # Keep track of the kdb atoms that have been mapped.
            print ("About to create initial mappings")
            print ("kdbmobile: ", kdbmobile)
            print ("reactantNeighbors: ",reactantNeighbors)
            print ("kdbNeighbors: ",kdbNeighbors)
            # Create the initial mappings.
            mappings = None
            db_a = kdbmobile[0] # This will be the selected mobile atom.
            for m in kdbmobile:
                mMappings = []
                for freeAtom in list(reactantNeighbors.keys()):
                    for elementType in reactantNeighbors[freeAtom]:
                        if elementType not in kdbNeighbors[m]:
                            break
                        if kdbNeighbors[m][elementType] != reactantNeighbors[freeAtom][elementType]:
                            break
                    else:
                        mMappings.append({m:freeAtom})
                if mappings == None:
                    mappings = mMappings
                if len(mMappings) < len(mappings):
                    mappings = mMappings
                    db_a = m

            kdbUnmapped.remove(db_a)

            #GH: precalculate the box inverse once
            ibox = numpy.linalg.inv(reactant.cell)
            #GH: auto detection for if we need PBC check
            d1 = numpy.linalg.norm(reactant.cell[0])
            d2 = numpy.linalg.norm(reactant.cell[1])
            d3 = numpy.linalg.norm(reactant.cell[2])
            micDist = min(d1,d2,d3)/2.0
            #print("micDist: ",micDist)
            micDist = 0
            print (mappings,"Initial mappings")
            while len(kdbUnmapped) > 0 and len(mappings) > 0:
                # Create a list of new mappings that will replace mappings at the
                # end of this iteration.
                newMappings = []
                # Select an unmapped atom from kdbmin.
                kdbAtom = kdbUnmapped.pop()
                # Get the distance between kdbAtom and every other atom in the kdb
                # configuration.
                kdbDistances = {}
                for i in range(len(kdbmin)):
                    kdbDistances[i] = numpy.linalg.norm(kdbmin.positions[kdbAtom] - kdbmin.positions[i])
                # Loop over each mapping and try to place kdbAtom.
                for mapping in mappings:
                    # Loop over each atom in the reactant.
                    for reactantAtom in range(len(reactant)):
                        # Make sure it has not already been mapped.
                        if reactantAtom in list(mapping.values()):
                            continue
                        # Loop over the atoms in mapping and see if the distance
                        # between reactantAtom and mapping.values() atoms is the same
                        # within dc (DISTANCE_CUTOFF) of the distance between kdbAtom
                        # and mapping.keys() atoms.
                        for DA in list(mapping.keys()):
                            RA = mapping[DA]
                            pbcVector = self.atomAtomPbcVector(reactant, RA, reactantAtom)
                            if kdbDistances[DA] > micDist and PBC_MAPPING_CHECK:
                                if not self.isDistance3(pbcVector, kdbDistances[DA], reactant.cell, dc):
                                    break
                            else:
                                if abs(kdbDistances[DA] - self.atomAtomPbcDistance(reactant, RA, reactantAtom)) > dc:
                                    break

                            #print("DA: ",kdbDistances[DA])
                            #print("pbcVectormag: ",numpy.linalg.norm(pbcVector)," ",pbcVector)
                            #if PBC_MAPPING_CHECK:
                            #    pbcBreak = (abs(kdbDistances[DA] - self.atomAtomPbcDistance(reactant, RA, reactantAtom)) > dc)
                            #    if not self.isDistance(pbcVector, kdbDistances[DA], reactant.cell, dc):
                            #        if not pbcBreak:
                            #            print("kdbDistance: ",kdbDistances[DA])
                            #            print("pbcVector: ",pbcVector)
                            #            print("pbcDistance: ",self.atomAtomPbcDistance(reactant, RA, reactantAtom))
                            #        break
                            #else:
                            #    isDistBreak = (not self.isDistance(pbcVector, kdbDistances[DA], reactant.cell, dc))
                            #    if abs(kdbDistances[DA] - self.atomAtomPbcDistance(reactant, RA, reactantAtom)) > dc:
                            #        if not isDistBreak:
                            #            print("kdbDistance: ",kdbDistances[DA])
                            #            print("pbcVector: ",pbcVector)
                            #            print("pbcDistance: ",self.atomAtomPbcDistance(reactant, RA, reactantAtom))
                            #        break

                        else:
                            newMapping = mapping.copy()
                            newMapping[kdbAtom] = reactantAtom
                            newMappings.append(newMapping)
                mappings = newMappings

            # Load the mode.
            #print ("entry after mapped ",entry)
            mode = copy.deepcopy(entry['mode'])

            # Loop over each mapping and try to find a rotation that aligns the
            # kdb configuration with the query configuration.
            for mapping in mappings:

                reactantrot = self.clump(reactant, list(mapping.values()), nf)

                # If no neighbors found, go to next mapping
                if reactantrot is None:
                    continue

                # Make a copy of kdbmin for rotation and put it in the box.
                kdbrot = kdbmin.copy()
                kdbrot.cell = reactant.cell.copy()
                
                # Rotation Matrix calculation start
                tb = kdbrot.copy()
                tb.positions -= self.centroid(tb)
                ta = tb.copy()
                offset = self.centroid(reactantrot, list(mapping.values()))
                i = 0
		#NK the mapping.keys() are sorted here just for the loop but the dictionary remains the same
                for m in sorted(mapping):
                    ta.positions[i] = tb.positions[m] + self.pbc((reactantrot.positions[mapping[m]] - offset) - tb.positions[m], reactantrot.cell)
                    i += 1
                ta.positions -= self.centroid(ta)
                m = numpy.dot(tb.positions.transpose(), ta.positions)
                sxx = m[0][0]
                sxy = m[0][1]
                sxz = m[0][2]
                syx = m[1][0]
                syy = m[1][1]
                syz = m[1][2]
                szx = m[2][0]
                szy = m[2][1]
                szz = m[2][2]
                n = numpy.zeros((4,4))
                n[0][1] = syz - szy
                n[0][2] = szx - sxz
                n[0][3] = sxy - syx
                n[1][2] = sxy + syx
                n[1][3] = szx + sxz
                n[2][3] = syz + szy
                n += n.transpose()
                n[0][0] =  sxx + syy + szz
                n[1][1] =  sxx - syy - szz
                n[2][2] = -sxx + syy - szz
                n[3][3] = -sxx - syy + szz
                w, v = numpy.linalg.eig(n)
                maxw = 0
                maxv = 0
                for i in range(len(w)):
                    if w[i] > maxw:
                        maxw = w[i]
                        maxv = v[:,i]
                Rmat = numpy.zeros((3,3))
                aa = maxv[0]**2
                bb = maxv[1]**2
                cc = maxv[2]**2
                dd = maxv[3]**2
                ab = maxv[0]*maxv[1]
                ac = maxv[0]*maxv[2]
                ad = maxv[0]*maxv[3]
                bc = maxv[1]*maxv[2]
                bd = maxv[1]*maxv[3]
                cd = maxv[2]*maxv[3]
                Rmat[0][0] = aa + bb - cc - dd
                Rmat[0][1] = 2*(bc-ad) 
                Rmat[0][2] = 2*(bd+ac) 
                Rmat[1][0] = 2*(bc+ad) 
                Rmat[1][1] = aa - bb + cc - dd
                Rmat[1][2] = 2*(cd-ab) 
                Rmat[2][0] = 2*(bd-ac) 
                Rmat[2][1] = 2*(cd+ab) 
                Rmat[2][2] = aa - bb - cc + dd
                Rmat = Rmat.transpose()
                # Rotation Matrix calculation end

                translation1 = self.centroid(kdbrot)
                kdbrot.positions -= translation1
                kdbrot.positions = numpy.dot(kdbrot.positions, Rmat)

                translation2 = self.centroid(reactantrot, list(mapping.values()))

                kdbrot.positions += translation2

                # Calculate a score for this mapping.
                score = max([numpy.linalg.norm(self.pbc(kdbrot.positions[m] - reactantrot.positions[mapping[m]], reactantrot.cell)) for m in mapping])

                if score > dc:
                    continue

                # Load the saddle from the database.
                kdbSaddle = copy.deepcopy(entry['saddle'])

                # Mirror the saddle if the mirror flag is set for this entry.
                if entry["mirror"]:
                    for i in range(len(kdbSaddle)):
                        kdbSaddle.positions[i] += 2.0 * (kdbmin.positions[0] - kdbSaddle.positions[i])

                # Load the product from the database.
                kdbProduct = copy.deepcopy(entry['product'])
                
                #Load the barriers for the process
                proc_barriers = copy.deepcopy(entry['barrier'])

                # Mirror the product if the mirror flag is set for this entry.
                if entry["mirror"]:
                    for i in range(len(kdbProduct)):
                        kdbProduct.positions[i] += 2.0 * (kdbmin.positions[0] - kdbProduct.positions[i])

                # Map the mode.
                if mode is not None:
                    modeTemp = reactantrot.positions * 0.0
                    for m in mapping:
                        modeTemp[mapping[m]] = mode[m]
                    try:
                        modeTemp /= numpy.linalg.norm(modeTemp)
                    except FloatingPointError:
                        mode = None

                # Perform the saddle transformation.
                kdbSaddle.positions -= translation1
                kdbSaddle.positions = numpy.dot(kdbSaddle.positions, Rmat)
                kdbSaddle.positions += translation2

                # Perform the mode transformation.
                if mode is not None:
                    modeTemp = numpy.dot(modeTemp, Rmat)

                # Perform the product transformation.
                kdbProduct.positions -= translation1
                kdbProduct.positions = numpy.dot(kdbProduct.positions, Rmat)
                kdbProduct.positions += translation2

                # Create the suggestion.
                suggestion = reactant.copy()
                sugproduct = reactant.copy()
                for m in mapping:
                    if mapping[m] not in suggestion.constraints[0].index:
                        suggestion.positions[mapping[m]] = kdbSaddle.positions[m]
                    if mapping[m] not in sugproduct.constraints[0].index:
                        sugproduct.positions[mapping[m]] = kdbProduct.positions[m]

                # Check for duplicates.
                if nodupes:
                    isdupe = False
                    for unique in uniques:
                        pan = self.per_atom_norm(unique.positions - suggestion.positions, suggestion.cell, ibox)
                        if max(pan) <= dc:
                            isdupe = True
                            break
                    if isdupe:
                        continue
                    uniques.append(suggestion.copy())

                # Rebox.
                if REBOX_SUGGESTIONS:
                    suggestion.positions = self.pbc(suggestion.positions, suggestion.cell)
                    sugproduct.positions = self.pbc(sugproduct.positions, sugproduct.cell)

                # Write suggestion.
                if mode is not None:
                    if KEEP_BARRIERS:
                        self.output_query(outputdir, numMatches, suggestion, sugproduct, modeTemp,processBarrier=proc_barriers)
                    else:
                        self.output_query(outputdir, numMatches, suggestion, sugproduct, modeTemp)
                else:
                    if KEEP_BARRIERS:
                        self.output_query(outputdir, numMatches, suggestion, sugproduct,processBarrier=proc_barriers)
                    else:
                        self.output_query(outputdir, numMatches, suggestion, sugproduct)

                entryMatches += 1
                numMatches += 1

            #print "%10d" % entryMatches
            print("KDB matches: ", entryMatches)

