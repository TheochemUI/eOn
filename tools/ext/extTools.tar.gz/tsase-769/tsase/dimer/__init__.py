from tsase.dimer.ssdimer import SSDimer_atoms
