from tsase.calculators.ZDP_5Gauss.ZDP_5Gauss import ZDP_5Gauss
