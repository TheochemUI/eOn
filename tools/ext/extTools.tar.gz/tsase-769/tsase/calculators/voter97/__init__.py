from tsase.calculators.voter97.voter97 import voter97
