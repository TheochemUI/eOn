from tsase.calculators.morse.morse import morse
