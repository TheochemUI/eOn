from tsase.calculators.w.w import w

